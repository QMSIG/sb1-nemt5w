// Configuration settings
export const OPENAI_API_KEY = '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';
export const AIRTABLE_API_KEY = 'patOFjeWkFd8jz2OQ.8e55e8f3a479c2b168ec8682734da54e4c546ed100d1945e29e9b9f3d59dbb71';
export const AIRTABLE_BASE_ID = 'appgIKTyfbU4rPwkQ';
export const AIRTABLE_TABLE_NAME = 'Database';
export const MODEL = 'gpt-3.5-turbo';